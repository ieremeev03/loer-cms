<script setup>
import {Link} from '@inertiajs/vue3';

defineProps({
    links: Array
});
</script>

<template>
    <div v-if="links.length > 3">
        <div class="flex flex-wrap -mb-1">
            <template v-for="(link, p) in links" :key="p">
                <div v-if="link.url === null" class="mr-1 mb-1 px-4 py-3 text-sm leading-4 text-gray-400 border rounded"
                     v-html="link.label"/>
                <Link v-else
                      class="mr-1 mb-1 px-4 py-3 text-sm leading-4 border rounded hover:bg-white focus:border-indigo-600 focus:text-indigo-600"
                      :class="{ 'bg-indigo-600 text-white hover:text-black': link.active }" :href="link.url" v-html="link.label">
                </Link>

            </template>
        </div>
    </div>
</template>