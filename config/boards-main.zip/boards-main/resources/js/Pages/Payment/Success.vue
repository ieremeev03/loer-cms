<script setup>
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Оплата проведена успешно" />

    <div>Оплата проведена успешно</div>
</template>