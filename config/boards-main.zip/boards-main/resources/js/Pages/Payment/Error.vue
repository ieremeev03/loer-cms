<script setup>
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Произошла ошибка при оплате" />

    <div>Произошла ошибка при оплате</div>
</template>