<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InstructorPrice extends Model
{
    protected $fillable = ['price'];
}
