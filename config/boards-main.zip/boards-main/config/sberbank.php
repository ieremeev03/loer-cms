<?php

return [
    'url' => env('SBERBANK_URL'),
    'username' => env('SBERBANK_USERNAME'),
    'password' => env('SBERBANK_PASSWORD'),
];