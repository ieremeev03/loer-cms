<?php

return [
    'url' => env('LIME_URL'),
    'token' => env('LIME_TOKEN'),
    'cashdeck_id' => env('LIME_CASHDESC_ID'),
    'installation_id' => env('LIME_INSTALLATION_ID'),
    'processing_id' => env('LIME_PROCESSING_ID'),
];